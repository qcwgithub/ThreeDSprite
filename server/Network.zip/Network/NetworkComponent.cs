﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;

namespace Model
{
    public abstract class NetworkComponent : Component, IDestroy
    {
        private NetServer Service;

        public readonly Dictionary<long, Session> Sessions = new Dictionary<long, Session>();

        public virtual IMessagePacker MessagePacker { get; set; }

        public virtual IMessageDispatcher MessageDispatcher { get; set; }

        public int Count
        {
            get { return this.Sessions.Count; }
        }

        public int AcceptCount
        {
            get { return Sessions.Values.Where(f => f.ChannelType == ChannelType.Accept).Count(); }
        }

        public void Awake(NetworkProtocol protocol, int packetSize = NetPacket.PacketSizeLength4)
        {
            switch (protocol)
            {
                case NetworkProtocol.KCP:
                    //this.Service = new KService();
                    //break;
                    throw new Exception("no support kcp");
                case NetworkProtocol.TCP:
                    this.Service = new TcpServer(packetSize);
                    break;
                case NetworkProtocol.WebSocket:
                    this.Service = new WsServer();
                    break;
            }
        }

        public void Awake(NetworkProtocol protocol, string address, int packetSize = NetPacket.PacketSizeLength4)
        {
            try
            {
                IPEndPoint ipEndPoint;
                switch (protocol)
                {
                    case NetworkProtocol.KCP:
                        //ipEndPoint = NetworkHelper.ToIPEndPoint(address);
                        //this.Service = new KService(ipEndPoint, (channel) => { this.OnAccept(channel); });
                        //break;
                        throw new Exception("no support kcp");
                    case NetworkProtocol.TCP:
                        ipEndPoint = NetworkHelper.ToIPEndPoint(address);
                        this.Service = new TcpServer(packetSize, ipEndPoint, (channel) => { this.OnAccept(channel); });
                        break;
                    case NetworkProtocol.WebSocket:
                        string[] prefixs = address.Split(';');
                        this.Service = new WsServer(prefixs, (channel) => { this.OnAccept(channel); });
                        break;
                }
            }
            catch (Exception e)
            {
                throw new Exception($"NetworkComponent Awake Error {address}", e);
            }
        }

        public void OnDestroy()
        {
            foreach (Session session in this.Sessions.Values.ToArray())
            {
                session.Dispose();
            }

            this.Service.Dispose();
        }

        public virtual Session OnAccept(NetClient channel)
        {
            Session session = Scene.Create<Session>();
            session.Parent = Entity;
            session.Awake(this, channel);

            this.Sessions.Add(session.Id, session);
            channel.Parent = session;
            channel.Start();
            return session;
        }

        public virtual void Remove(long id)
        {
            Session session;
            if (!this.Sessions.TryGetValue(id, out session))
            {
                return;
            }
            this.Sessions.Remove(id);
            session.Dispose();
        }

        public Session Get(long id)
        {
            Session session;
            this.Sessions.TryGetValue(id, out session);
            return session;
        }

        public Session[] GetAll()
        {
            return Sessions.Values.ToArray();
        }

        /// <summary>
        /// 创建一个新Session
        /// </summary>
        public virtual Session Create(IPEndPoint ipEndPoint)
        {
            NetClient channel = Service.ConnectChannel(ipEndPoint);
            Session session = Scene.Create<Session>();
            session.Parent = Entity;
            session.Awake(this, channel);

            this.Sessions.Add(session.Id, session);
            channel.Parent = session;
            channel.Start();
            return session;
        }

        /// <summary>
        /// 创建一个新Session
        /// </summary>
        public virtual Session Create(string address)
        {
            NetClient channel = Service.ConnectChannel(address);
            Session session = Scene.Create<Session>();
            session.Parent = Entity;
            session.Awake(this, channel);

            this.Sessions.Add(session.Id, session);
            channel.Parent = session;
            channel.Start();
            return session;
        }
    }
}

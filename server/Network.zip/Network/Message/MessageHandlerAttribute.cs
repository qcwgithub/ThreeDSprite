﻿using System;

namespace Model
{
    public class MessageHandlerAttribute : Attribute
    {
    }
}
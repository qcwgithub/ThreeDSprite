﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    [AttributeUsage(AttributeTargets.Class)]
    public class MessageAttribute : Attribute
    {
        public ushort Opcode { get; }

        public MessageAttribute(ushort opcode)
        {
            Opcode = opcode;
        }
    }

    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true, Inherited = false)]
    public class OnMessageAttribute : Attribute
    { 
        public ushort Opcode { get; }

        public OnMessageAttribute(ushort opcode)
        {
            Opcode = opcode;
        }

        public OnMessageAttribute(Type type)
        {
            Opcode = MessageComponent.Instance.GetOpcode(type);
        }
    }
}

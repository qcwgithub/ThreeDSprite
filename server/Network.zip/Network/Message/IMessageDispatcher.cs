﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public interface IMessageDispatcher
    {
        void Dispatch(Session session, ushort opcode, object message);
    }
}

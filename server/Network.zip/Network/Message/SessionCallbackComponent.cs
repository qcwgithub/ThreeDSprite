﻿using System;
using System.IO;

namespace Model
{
    public class SessionCallbackComponent : Component, IDestroy
    {
        public Action<Session, ushort, MemoryStream> MessageCallback;
        public Action<Session> DisposeCallback;

        public void OnDestroy()
        {
            DisposeCallback?.Invoke(this.GetEntity<Session>());
            DisposeCallback = null;
        }
    }
}

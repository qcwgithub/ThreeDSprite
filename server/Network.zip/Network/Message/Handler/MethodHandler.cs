﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class MethodHandler
    {
        public IComponentSystem System { get; }
        public MethodInfo Method { get; }

        public MethodHandler(IComponentSystem system, MethodInfo method)
        {
            System = system;
            Method = method;
        }

        public async void Handle(Session session, object msg)
        {
            switch (msg)
            {
                case IRequest request:
                    int rpcId = request.RpcId;
                    long instanceId = session.InstanceId;
                    void reply(IResponse response)
                    {
                        // 等回调回来,session可能已经断开了
                        if (session.InstanceId != instanceId)
                            return;

                        response.RpcId = rpcId;
                        session.Reply(response);
                    }

                    try
                    {
                        var result = Method.Invoke(System, new object[] { session, request });

                        if (result is Task task)
                        {
                            await task;
                            result = task.GetType().GetProperty("Result").GetValue(task, null);
                        }

                        if (result == null)
                            throw new Exception("Response value can't null");

                        var response = result as IResponse;
                        if (response == null)
                            throw new Exception($"Response type error : {result.GetType().Name}");

                        reply(response);
                    }
                    catch (Exception e)
                    {
                        Log.Error(e);
                        var response = new ResponseMessage();
                        response.Error = ErrorCode.ERR_RpcFail;
                        response.Message = e.ToString();
                        reply(response);
                    }
                    break;

                case IMessage message:

                    Method.Invoke(System, new object[] { session, message });

                    break;

                default:
                    Log.Error($"消息类型转换错误: {msg.GetType().Name}");
                    break;
            }
        }
    }
}

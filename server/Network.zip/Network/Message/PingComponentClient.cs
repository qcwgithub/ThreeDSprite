﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Model
{
    /// <summary>
    /// Session心跳组件(需要挂载到Session上)
    /// </summary>
    public class PingComponentClient : Component, IUpdate
    {
        // Ping检测间隔时间
        public static int CheckInterval = 5000;

        // 超时间隔
        public static long TimeoutInterval = 5000;

        // 超时回调
        public event Action TimeoutCallback;

        // 上次Ping时间
        private long lastPingTime;

        // 上一帧时间
        private long lastDeltaTime;

        // Ping值(ms)
        private int ping;
        public int Ping
        {
            private set
            {
                ping = value > 0 ? value : 1;
            }
            get
            {
                var session = GetEntity<Session>();
                if (session == null || session.IsDisposed)
                    return 9999;

                return ping;
            }
        }

        public void OnDestroy()
        {
            TimeoutCallback = null;
        }

        public void OnUpdate()
        {
            // 延迟检测
            CheckPing();

#if !SERVER
            var delta = (long)(UnityEngine.Time.deltaTime * 1000);
            lastDeltaTime = delta > lastDeltaTime ? delta : lastDeltaTime;
#endif
        }

        private async void CheckPing()
        {
            var now = TimeHelper.Now();
            if ((now - lastPingTime) < CheckInterval)
                return;

            var session = GetEntity<Session>();
            if (session == null || session.IsDisposed)
                return;

            // 记录检测时间
            lastPingTime = now;

            // 发送检测
            try
            {
                lastDeltaTime = 0;
                R2C_Ping result = (R2C_Ping)await session.Call(new C2R_Ping(), TimeoutInterval);
                Ping = (int)(TimeHelper.Now() - lastPingTime - lastDeltaTime);
            }
            catch (Exception e)
            {
                //Log.Error(e);
                TimeoutCallback?.Invoke();
                session.Dispose();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class MessageComponent : Component, IAwake, ILoad
    {
        public static MessageComponent Instance;

        private readonly DoubleMap<ushort, Type> opcodeTypes = new DoubleMap<ushort, Type>();

        private readonly Dictionary<ushort, object> typeMessages = new Dictionary<ushort, object>();

        public void OnAwake()
        {
            Instance = this;
            OnLoad();
        }

        public void OnLoad()
        {
            opcodeTypes.Clear();
            typeMessages.Clear();

            var types = DllHelper.GetMonoTypes();
            foreach (Type type in types)
            {
                object[] attrs = type.GetCustomAttributes(typeof(MessageAttribute), false);
                if (attrs.Length == 0)
                    continue;

                var messageAttribute = attrs[0] as MessageAttribute;
                if (messageAttribute == null)
                    continue;

                opcodeTypes.Add(messageAttribute.Opcode, type);
                typeMessages.Add(messageAttribute.Opcode, Activator.CreateInstance(type));
            }
        }

        public ushort GetOpcode(Type type)
        {
            return opcodeTypes.GetKeyByValue(type);
        }

        public Type GetType(ushort opcode)
        {
            return opcodeTypes.GetValueByKey(opcode);
        }

        // 客户端为了0GC需要消息池，服务端消息需要跨协程不需要消息池
        public object GetInstance(ushort opcode)
        {
#if SERVER
            Type type = GetType(opcode);
            if (type == null)
            {
                // 服务端因为有人探测端口，有可能会走到这一步，如果找不到opcode，抛异常
                throw new Exception($"not found opcode: {opcode}");
            }
            return Activator.CreateInstance(type);
#else
            return typeMessages[opcode];
#endif
        }
    }
}

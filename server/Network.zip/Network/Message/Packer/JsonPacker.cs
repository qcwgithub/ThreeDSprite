﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class JsonPacker : IMessagePacker
    {
        public byte[] SerializeTo(object obj)
        {
#if SERVER
            return JsonHelper.ToStandardJson(obj).ToUtf8();
#else
            return JsonHelper.ToJson(obj).ToUtf8();
#endif
        }

        public void SerializeTo(object obj, MemoryStream stream)
        {
            var bytes = SerializeTo(obj);
            stream.Write(bytes, 0, bytes.Length);
        }

        public object DeserializeFrom(Type type, byte[] bytes)
        {
#if SERVER
            return JsonHelper.FromStandardJson(type, bytes.Utf8ToStr());
#else
            return JsonHelper.FromJson(type, bytes.Utf8ToStr());
#endif
        }

        public object DeserializeFrom(Type type, byte[] bytes, int index, int count)
        {
            object t;
            using (MemoryStream ms = new MemoryStream(bytes, index, count))
            {
                t = DeserializeFrom(type, ms);
            }
            return t;
        }

        public object DeserializeFrom(object instance, byte[] bytes, int index, int count)
        {
            throw new NotImplementedException();
        }

        public object DeserializeFrom(Type type, MemoryStream stream)
        {
            byte[] bytes = new byte[stream.Length - stream.Position];
            stream.Read(bytes, 0, bytes.Length);
            return DeserializeFrom(type, bytes);
        }

        public object DeserializeFrom(object instance, MemoryStream stream)
        {
            throw new NotImplementedException();
        }
    }
}

﻿
namespace Model
{
    public class NetOuterComponentSystem : ComponentSystem<NetOuterComponent, string>
    {
        public override void OnAwake(NetOuterComponent self)
        {
            self.Awake(self.Protocol);
            self.MessageDispatcher = new OuterMessageDispatcher();
        }

        public override void OnAwake(NetOuterComponent self, string address)
        {
            self.Awake(self.Protocol, address);
            self.MessageDispatcher = new OuterMessageDispatcher();
        }

        public override void OnLoad(NetOuterComponent self)
        {
            self.MessageDispatcher = new OuterMessageDispatcher();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Model
{
    /// <summary>
    /// 通讯会话对象
    /// </summary>
    public sealed class Session : Entity, IDestroy
    {
        private static int RpcId { get; set; }
        private NetClient channel;

        private readonly Dictionary<int, Action<IResponse>> requestCallback = new Dictionary<int, Action<IResponse>>();
        private readonly byte[] opcodeBytes = new byte[2];

        public event Action DisposedCallback;
        public NetworkComponent Network { get; private set; }
        public object Client { get; set; }
        public long LastRecvTime { get; private set; }
        public long LastSendTime { get; private set; }

        // 是否回收空连接
        public bool IsRecoveryNouse { get; set; } = true;

        public int Error
        {
            get
            {
                return this.channel.Error;
            }
            set
            {
                this.channel.Error = value;
            }
        }

        public void Awake(NetworkComponent net, NetClient aChannel)
        {
            this.Network = net;
            this.channel = aChannel;
            this.requestCallback.Clear();

            long timeNow = TimeHelper.Now();
            this.LastRecvTime = timeNow;
            this.LastSendTime = timeNow;

            long id = this.Id;
            channel.ErrorCallback += (c, e) =>
            {
                this.Network.Remove(id);
            };
            channel.ReadCallback += this.OnRead;
        }

        public void OnDestroy()
        {
            foreach (Action<IResponse> action in this.requestCallback.Values.ToArray())
            {
                action.Invoke(new ResponseMessage { Error = ErrorCode.ERR_SocketDisconnected });
            }

            this.requestCallback.Clear();
            this.channel.Dispose();
            this.Network.Remove(Id);
            this.Client = null;
            this.DisposedCallback?.Invoke();
            this.DisposedCallback = null;
            this.IsRecoveryNouse = true;
        }

        public string RemoteAddress
        {
            get
            {
                return this.channel.RemoteAddress;
            }
        }

        public ChannelType ChannelType
        {
            get
            {
                return this.channel.ChannelType;
            }
        }

        public MemoryStream Stream
        {
            get
            {
                return this.channel.Stream;
            }
        }

        public void OnRead(MemoryStream memoryStream)
        {
            try
            {
                this.Run(memoryStream);
            }
            catch (Exception e)
            {
                Log.Error(e);
            }
        }

        private void Run(MemoryStream memoryStream)
        {
            memoryStream.Seek(NetPacket.MessageIndex, SeekOrigin.Begin);
            ushort opcode = BitConverter.ToUInt16(memoryStream.GetBuffer(), NetPacket.OpcodeIndex);

#if !SERVER
            if (NetworkHelper.IsClientHotfixMessage(opcode))
            {
                this.GetComponent<SessionCallbackComponent>().MessageCallback.Invoke(this, opcode, memoryStream);
                return;
            }
#endif
            object message = null;
            try
            {
                var type = MessageComponent.Instance.GetType(opcode);
                message = Network.MessagePacker.DeserializeFrom(type, memoryStream);

                if (NetworkHelper.IsNeedDebugLogMessage(opcode))
                {
                    Log.Debug(JsonHelper.ToJson(message));
                }
            }
            catch (Exception e)
            {
                // 出现任何消息解析异常都要断开Session，防止客户端伪造消息
                Log.Error($"解析消息包错误：opcode = {opcode}, ip = {this.RemoteAddress}, connectCount = {this.Network.Count}\n{e}");
                this.Error = ErrorCode.ERR_PacketParserError;
                this.Network.Remove(this.Id);
                return;
            }

            RunMessage(opcode, message);
        }

        private void RunMessage(ushort opcode, object message)
        {
            this.LastRecvTime = TimeHelper.Now();

            if (!(message is IResponse))
            {
                this.Network.MessageDispatcher.Dispatch(this, opcode, message);
                return;
            }

#if SERVER
            if (message is IActorResponse)
            {
                this.Network.MessageDispatcher.Dispatch(this, opcode, message);
                return;
            }
#endif

            var response = message as IResponse;
            if (response == null)
            {
                throw new Exception($"message is not response : {opcode}");
            }

            Action<IResponse> action;
            if (!requestCallback.TryGetValue(response.RpcId, out action))
            {
                throw new Exception($"not found rpc, response message: {response.GetType().Name}");
            }
            requestCallback.Remove(response.RpcId);

            action(response);
        }

        // 注册超时异常
        private void RegTimeout(int rpcId, long timeOutInterval)
        {
            // 超时没回复抛超时异常
            TimerHelper.Delay(timeOutInterval, () =>
            {
                if (IsDisposed)
                    return;

                Action<IResponse> action;
                if (!this.requestCallback.TryGetValue(rpcId, out action))
                    return;

                this.requestCallback.Remove(rpcId);
                action.Invoke(new ResponseMessage { Error = ErrorCode.ERR_SocketExpire });
            });
        }

        public Task<IResponse> CallWithoutException(IRequest request)
        {
            if (IsDisposed)
            {
                throw new Exception("session is disposed");
            }

            int rpcId = ++RpcId;
            var tcs = new TaskCompletionSource<IResponse>();
            this.requestCallback[rpcId] = (response) =>
            {
                tcs.SetResult(response);
            };

            request.RpcId = rpcId;
            this.Send(request);
            return tcs.Task;
        }

        public Task<IResponse> Call(IRequest request, long timeOutInterval = 0)
        {
            if (IsDisposed)
            {
                throw new Exception("session is disposed");
            }

            int rpcId = ++RpcId;
            var tcs = new TaskCompletionSource<IResponse>();
            this.requestCallback[rpcId] = (response) =>
            {
                if (ErrorCode.IsRpcNeedThrowException(response.Error))
                {
                    tcs.SetException(new Exception($"Rpc error: {JsonHelper.ToJson(response)}"));
                    return;
                }

                tcs.SetResult(response);
            };

            if (timeOutInterval > 0) RegTimeout(rpcId, timeOutInterval);

            request.RpcId = rpcId;
            this.Send(request);
            return tcs.Task;
        }

        public void Reply(IResponse message)
        {
            this.Send(message);
        }

        public void Send(IMessage message)
        {
            ushort opcode = MessageComponent.Instance.GetOpcode(message.GetType());
            Send(opcode, message);
        }

        public void Send(ushort opcode, object message)
        {
            if (IsDisposed)
                return;

            this.LastSendTime = TimeHelper.Now();

            if (NetworkHelper.IsNeedDebugLogMessage(opcode))
            {
                Log.Debug($"发送消息：opcode = {opcode}, msg = {JsonHelper.ToJson(message)}");
            }

            MemoryStream stream = this.Stream;

            stream.Seek(NetPacket.MessageIndex, SeekOrigin.Begin);
            stream.SetLength(NetPacket.MessageIndex);
            this.Network.MessagePacker.SerializeTo(message, stream);
            stream.Seek(0, SeekOrigin.Begin);

            opcodeBytes.WriteTo(0, opcode);
            Array.Copy(opcodeBytes, 0, stream.GetBuffer(), 0, opcodeBytes.Length);

            this.Send(stream);
        }

        public void Send(MemoryStream stream)
        {
            channel.Send(stream);
        }
    }
}

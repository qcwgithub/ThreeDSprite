﻿using System;
using System.Collections.Generic;

namespace Model
{
    public class NetOuterComponent : NetworkComponent
    {
        public override IMessagePacker MessagePacker { get; set; } = new ProtobufPacker();

        public NetworkProtocol Protocol = NetworkProtocol.WebSocket;
    }
}
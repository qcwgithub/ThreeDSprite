namespace Model
{
    public partial class ErrorCode
    {
        public static int ERR_Fail = 0;

        #region SocketError��1-11004���뿴SocketError����

        #endregion

        #region ϵͳ�쳣��20000-100000��

        public static int ERR_RpcFail = 20001;
        public static int ERR_SocketDisconnected = 20002;
        public static int ERR_ReloadFail = 20003;
        public static int ERR_ActorLocationNotFound = 20004;
        public static int ERR_SocketExpire = 20005;
        public static int ERR_HotfixCodeFail = 20006;
        public static int ERR_HotfixConfigFail = 20007;
        public static int ERR_NotFoundActor = 20008;
        public static int ERR_ActorTimeout = 20009;
        public static int ERR_ActorRemove = 20010;
        public static int ERR_ActorNotOnline = 20011;
        public static int ERR_PacketParserError = 20012;

        public static int ERR_KcpCantConnect = 20101;
        public static int ERR_KcpChannelTimeout = 20102;
        public static int ERR_KcpRemoteDisconnect = 20103;
        public static int ERR_PeerDisconnect = 20104;
        public static int ERR_SocketCantSend = 20105;
        public static int ERR_SocketError = 20106;
        public static int ERR_KcpWaitSendSizeTooLarge = 20107;
        public static int ERR_SessionSendOrRecvTimeout = 20108;

        public static int ERR_WebsocketPeerReset = 20201;
        public static int ERR_WebsocketMessageTooBig = 20202;
        public static int ERR_WebsocketError = 20203;
        public static int ERR_WebsocketConnectError = 20204;
        public static int ERR_WebsocketSendError = 20205;
        public static int ERR_WebsocketRecvError = 20206;

        public static bool IsRpcNeedThrowException(int error)
        {
            if (error == 0)
            {
                return false;
            }

            if (error > ERR_Exception)
            {
                return false;
            }

            return true;
        }

        #endregion

        // С�����Rpc�����쳣����������쳣��error��Ҫ�Լ��жϴ�����Ҳ����˵��Ҫ�����Ĵ���Ӧ��Ҫ���ڸ�ֵ
        public static int ERR_Exception = 100000;
    }
}
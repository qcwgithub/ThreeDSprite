﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Model
{
    public enum NetworkProtocol
    {
        TCP,
        KCP,
        WebSocket,
    }

    public abstract class NetServer : Entity, IDestroy
    {
        public abstract NetClient GetChannel(long id);

        private Action<NetClient> acceptCallback;

        public event Action<NetClient> AcceptCallback
        {
            add
            {
                this.acceptCallback += value;
            }
            remove
            {
                this.acceptCallback -= value;
            }
        }

        protected void OnAccept(NetClient channel)
        {
            this.acceptCallback.Invoke(channel);
        }

        public abstract NetClient ConnectChannel(IPEndPoint ipEndPoint);

        public abstract NetClient ConnectChannel(string address);

        public abstract void Remove(long channelId);

        public abstract void OnDestroy();
    }
}
﻿using Microsoft.IO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Threading;

namespace Model
{
    public class WsClient : NetClient
    {
        public HttpListenerContext Context { get; set; }

        public HttpListenerWebSocketContext WebSocketContext { get; }

        private readonly WebSocket webSocket;

        private readonly Queue<byte[]> sendQueue = new Queue<byte[]>();

        private Queue<MemoryStream> recvQueue = new Queue<MemoryStream>();

        private bool isSending;

        private bool isConnected;

        private readonly MemoryStream sendStream;

        private CancellationTokenSource cts = new CancellationTokenSource();

        public WsClient(HttpListenerContext context, HttpListenerWebSocketContext webSocketContext, NetServer service) : base(service, ChannelType.Accept)
        {
            this.Context = context;

            this.WebSocketContext = webSocketContext;

            this.webSocket = webSocketContext.WebSocket;

            this.sendStream = this.GetService().MemoryStreamManager.GetStream("message", WsServer.BufferSizeMax);

            this.RemoteAddress = context.GetIp();

            isConnected = true;
        }

        public WsClient(string address, WebSocket webSocket, NetServer service) : base(service, ChannelType.Connect)
        {
            this.webSocket = webSocket;

            this.sendStream = this.GetService().MemoryStreamManager.GetStream("message", WsServer.BufferSizeMax);

            isConnected = false;
        }

        public override void OnDestroy()
        {
            this.cts.Cancel();
            this.cts.Dispose();
            this.cts = null;

            this.webSocket.Dispose();
            this.Context?.Close();
            this.sendStream.Dispose();
            this.sendQueue.Clear();

            foreach (var recv in recvQueue)
                recv.Dispose();
            this.recvQueue.Clear();
        }

        public override MemoryStream Stream
        {
            get
            {
                return this.sendStream;
            }
        }

        public override void Start()
        {
            if (!this.isConnected)
            {
                return;
            }

            this.StartRecv();
            this.StartSend();
        }

        private WsServer GetService()
        {
            return (WsServer)this.Service;
        }

        public async void ConnectAsync(string url)
        {
            try
            {
                await ((ClientWebSocket)this.webSocket).ConnectAsync(new Uri(url), cts.Token);
                isConnected = true;
                this.Start();
            }
            catch (Exception e)
            {
                Log.Error($"Websocket connect fail : {url}\n{e}");
                this.OnError(ErrorCode.ERR_WebsocketConnectError);
            }
        }

        public override void Send(MemoryStream stream)
        {
            if (stream.Length <= 0)
            {
                throw new Exception($"send message length : {stream.Length}");
            }

            if (stream.Length >= GetService().MemoryStreamManager.BlockSize)
            {
                stream.Seek(NetPacket.MessageIndex, SeekOrigin.Begin);
                ushort opcode = BitConverter.ToUInt16(stream.GetBuffer(), NetPacket.OpcodeIndex);
                throw new Exception($"send message too big: length = {stream.Length}, opcode = {opcode}");
            }

            byte[] bytes = new byte[stream.Length];
            Array.Copy(stream.GetBuffer(), bytes, bytes.Length);
            this.sendQueue.Enqueue(bytes);

            this.StartSend();
        }

        public async void StartSend()
        {
            try
            {
                if (this.IsDisposed)
                {
                    return;
                }

                if (!this.isConnected)
                {
                    return;
                }

                if (this.isSending)
                {
                    return;
                }

                this.isSending = true;
                var instanceId = InstanceId;
                while (true)
                {
                    if (instanceId != InstanceId)
                    {
                        return;
                    }

                    // 检查断开状态
                    if (webSocket.State != WebSocketState.Open)
                    {
                        this.OnError(ErrorCode.ERR_WebsocketPeerReset);
                        return;
                    }

                    if (this.sendQueue.Count == 0)
                    {
                        this.isSending = false;
                        return;
                    }

                    byte[] bytes = this.sendQueue.Dequeue();
#if SERVER
                    await webSocket.SendAsync(new ReadOnlyMemory<byte>(bytes), WebSocketMessageType.Binary, true, cts.Token);
#else
                    await webSocket.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Binary, true, cts.Token);
#endif
                }
            }
            catch (WebSocketException e)
            {
                //Log.Error(e);
                OnError(ErrorCode.ERR_WebsocketSendError);
            }
            catch (Exception e)
            {
                Log.Error(e);
                OnError(ErrorCode.ERR_WebsocketSendError);
            }
        }

        public async void StartRecv()
        {
            var stream = this.GetService().MemoryStreamManager.GetStream("message", WsServer.BufferSizeMax);
            int receiveCount = 0;
            var instanceId = this.InstanceId;
            try
            {
                do
                {
#if SERVER
                    var result = await webSocket.ReceiveAsync(new Memory<byte>(stream.GetBuffer(), receiveCount, stream.Capacity - receiveCount), cts.Token);
#else
                    var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(stream.GetBuffer(), receiveCount, stream.Capacity - receiveCount), cts.Token);
#endif
                    receiveCount += result.Count;

                    if (instanceId != this.InstanceId)
                    {
                        return;
                    }

                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        OnError(ErrorCode.ERR_WebsocketPeerReset);
                        return;
                    }

                    // 接收完成
                    if (result.EndOfMessage)
                    {
                        break;
                    }

                    // 接收内容长度是否超出buffer大小
                    if (receiveCount >= WsServer.BufferSizeMax)
                    {
                        Log.Error($"recv message too big: {receiveCount}");
                        await webSocket.CloseAsync(WebSocketCloseStatus.MessageTooBig, $"message too big: {receiveCount}", cts.Token);
                        OnError(ErrorCode.ERR_WebsocketMessageTooBig);
                        return;
                    }
                }
                while (true);
            }
            catch (WebSocketException e)
            {
                //Log.Error(e);
                OnError(ErrorCode.ERR_WebsocketRecvError);
                return;
            }
            catch (Exception e)
            {
                //Log.Error(e);
                OnError(ErrorCode.ERR_WebsocketRecvError);
                return;
            }

            if (receiveCount > 0)
            {
                stream.SetLength(receiveCount);
                recvQueue.Enqueue(stream);
            }

            // 继续接收
            StartRecv();

            // 处理消息
            StartHandle();
        }

        private void StartHandle()
        {
            if (recvQueue.Count == 0)
                return;

            var stream = recvQueue.Dequeue();
            OnRead(stream);
            stream.Dispose();
        }
    }
}

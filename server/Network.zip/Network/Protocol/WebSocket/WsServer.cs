﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using Microsoft.IO;

namespace Model
{
    public class WsServer : NetServer
    {
        public const int BufferSizeMax = 1024 * 1024;

        private readonly HttpListener httpListener;

        private readonly Dictionary<long, WsClient> channels = new Dictionary<long, WsClient>();

        public RecyclableMemoryStreamManager MemoryStreamManager = new RecyclableMemoryStreamManager(BufferSizeMax, RecyclableMemoryStreamManager.DefaultLargeBufferMultiple, RecyclableMemoryStreamManager.DefaultMaximumBufferSize);

        public WsServer(IEnumerable<string> prefixs, Action<NetClient> acceptCallback)
        {
            this.AcceptCallback += acceptCallback;

            this.httpListener = new HttpListener();

            StartAccept(prefixs);
        }

        public WsServer()
        {
        }

        public override void OnDestroy()
        {
        }

        public override NetClient GetChannel(long id)
        {
            WsClient channel;
            this.channels.TryGetValue(id, out channel);
            return channel;
        }

        public override NetClient ConnectChannel(IPEndPoint ipEndPoint)
        {
            throw new NotImplementedException();
        }

        public override NetClient ConnectChannel(string address)
        {
            ClientWebSocket webSocket = new ClientWebSocket();
            WsClient channel = new WsClient(address, webSocket, this);
            this.channels[channel.Id] = channel;
            channel.ConnectAsync(address);
            return channel;
        }

        public override void Remove(long id)
        {
            WsClient channel;
            if (!this.channels.TryGetValue(id, out channel))
            {
                return;
            }

            this.channels.Remove(id);
            channel.Dispose();
        }

        public async void StartAccept(IEnumerable<string> prefixs)
        {
            try
            {
                var sb = new StringBuilder();
                foreach (string prefix in prefixs)
                {
                    if (prefix.Trim().IsNullOrEmpty())
                        continue;

                    this.httpListener.Prefixes.Add(prefix);
                    sb.Append(prefix);
                    sb.Append(";");
                }

                httpListener.Start();
                Log.Info($"listen ws : {sb}");

                var instanceId = InstanceId;
                while (instanceId == InstanceId)
                {
                    HttpListenerContext httpListenerContext = null;
                    try
                    {
                        httpListenerContext = await httpListener.GetContextAsync();
                        if (!httpListenerContext.Request.IsWebSocketRequest)
                        {
                            httpListenerContext.Close();
                            continue;
                        }

                        HttpListenerWebSocketContext webSocketContext = await httpListenerContext.AcceptWebSocketAsync(null);
                        WsClient channel = new WsClient(httpListenerContext, webSocketContext, this);
                        this.channels[channel.Id] = channel;
                        this.OnAccept(channel);
                    }
                    catch (Exception e)
                    {
                        httpListenerContext.Close();
                        Log.Error($"Accept websocket connection fail\n{e}");
                    }
                }
            }
            catch (HttpListenerException e)
            {
                if (e.ErrorCode == 5)
                {
                    var sb = new StringBuilder();
                    sb.AppendLine("请运行/Tools/ResetHttpPort.bat或手动执行CMD命令");
                    foreach (string prefix in prefixs)
                        sb.AppendLine($"netsh http add urlacl url={prefix} user=Everyone");

                    throw new Exception(sb.ToString(), e);
                }

                Log.Error(e);
            }
            catch (Exception e)
            {
                Log.Error(e);
            }
        }
    }
}

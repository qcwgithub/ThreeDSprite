﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace Model
{
    public enum ChannelType
    {
        Connect,
        Accept,
    }

    public abstract class NetClient : Entity, IDestroy
    {
        public ChannelType ChannelType { get; }

        public NetServer Service { get; }

        public abstract MemoryStream Stream { get; }

        public int Error { get; set; }

        public string RemoteAddress { get; protected set; }

        private event Action<NetClient, int> errorCallback;

        public event Action<NetClient, int> ErrorCallback
        {
            add
            {
                this.errorCallback += value;
            }
            remove
            {
                this.errorCallback -= value;
            }
        }

        private Action<MemoryStream> readCallback;

        public event Action<MemoryStream> ReadCallback
        {
            add
            {
                this.readCallback += value;
            }
            remove
            {
                this.readCallback -= value;
            }
        }

        protected void OnRead(MemoryStream memoryStream)
        {
            this.readCallback.Invoke(memoryStream);
        }

        protected void OnError(int e)
        {
            this.Error = e;
            this.errorCallback?.Invoke(this, e);
        }


        protected NetClient(NetServer service, ChannelType channelType)
        {
            this.ChannelType = channelType;
            this.Service = service;
        }

        public virtual void Start() { }

        public abstract void Send(MemoryStream stream);

        public virtual void OnDestroy()
        {
            this.Service.Remove(this.Id);
        }
    }
}
